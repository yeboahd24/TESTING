import os
import requests


username = 'US4GZonm5BjNKDJUML2odaQ6'
passwd = 'af9305d0-80ef-4c86-96ee-4f32f7941dce'
vault = 'tnttukbbvmi'


"""NOW WE CAN MAKE A REQUEST
    NOW COPY THE CVV AND CARD NUMBER FROM THE RESPONSE OF THE cvv_token file,
    AND PASTE THEM IN THE BELOW CODE
"""


def payment_initiation():
    os.environ['HTTPS_PROXY'] = 'http://' + username + ':' + \
        passwd + '@' + vault + '.sandbox.verygoodproxy.com:8080'

    response = requests.post('https://api.flutterwave.com/v3/charges?type=card',
                             headers={
                                 "Content-type": "application/json",
                                 "Secret-Key": "tok_sandbox_rVdCJgokR3bK7EdXU3d1hs",
                             },
                             json={
                                 "amount": 200,
                                 "card_number": "tok_sandbox_5xCjcCyYWchHkSNfkmnFBv",
                                 "cvv": "tok_sandbox_wHScJ95BdJHiiB8hpf8N9R",
                                 "expiry_month": "09",
                                 "expiry_year": "34",
                                 "currency": "GHS",
                                 "country": "GH",
                                 "redirect_url": "https://webhook.site/c1ff1154-8535-4d1a-99a6-5b32cc5c366d",
                                 "email": "yeboahd24@gmail.com", "phone_number": "0540303211",
                                 "preauthorize": "True",
                                 "tx_ref": "MC-3243e", "authorization": {
                                     "mode": "pin",
                                     "pin": "3310",
                                 }
                             },
                             verify="./sandbox.pem")
    print(str(response.text))


""" NOW THIS CODE VALIDATES THE RESPONSE
    IF THE RESPONSE IS VALID, IT WILL RETURN A 200 RESPONSE CODE
    IF THE RESPONSE IS NOT VALID, IT WILL RETURN A 400 RESPONSE CODE,
    OTP: THE OTP THAT WAS SENT TO THE USER'S PHONE NUMBER
    FLW_REF: THE FLUTTERWAVE REFERENCE NUMBER, IT IS USED TO VALIDATE THE RESPONSE,
    AND TO FIND THE TRANSACTION IN THE FLUTTERWAVE API.

    NB: BEFORE YOU CAN USE THIS CODE, YOU MUST HAVE COMMENT OUT THE TOP LINE OF CODE,
    payment_initiation().
"""


def validate_response(otp="12345",
                      flw_ref="FLW-MOCK-48185353b40dcb405434c48a87178b7c"):
    url = "https://api.flutterwave.com/v3/validate-charge"

    payload = {
        "otp": otp,
        "flw_ref": flw_ref,
        "type": "card"
    }
    _headers = {
        "Accept": "application/json",
        "Authorization": "Bearer FLWSECK_TEST-88ebd2a6edb534bbc663d33efcd1211a-X",
        "Content-Type": "application/json"
    }

    response2 = requests.request("POST", url, json=payload, headers=_headers)
    print(str(response2.text))
