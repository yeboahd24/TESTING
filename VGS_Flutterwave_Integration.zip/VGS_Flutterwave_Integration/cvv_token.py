import requests

"""THIS IS A TEST FILE, IT HASHES THE CVV AND TOKENS AND SENDS THEM TO THE API
   TAKE THE HASHED CVV AND CARD_NUMBER AND PUT IT IN THE CORRECT PLACE IN THE
    API CALL OF sample-via-proxy.py FILE"""

base_url = 'https://tnttukbbvmi.sandbox.verygoodproxy.com/post'
headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
}

json = {
    "secret_key": "FLWSECK_TEST-88ebd2a6edb534bbc663d33efcd1211a-X",
    "card_number": "5531886652142950",
    "cvv": "564"}

response = requests.post(base_url, json=json, headers=headers)
print(response.text)
